# SE IPTV PLAYER

Android IPTV player based on the Orbital project, converted into the SE IPTV PLAYER application.

## Fixed application identity
- App name: **SE IPTV PLAYER**
- Version: **V10.1.0**
- Version is fixed at V10.1.0 for this project.

## Update policy
There is **no update mechanism** in this app: no automatic update check, no manual check, no update button, and no in-app APK download/install flow.

## Branding
- The SE artwork is used only on the Xtream Codes login screen.
- The same SE artwork is used for the launcher/app icon.
- Channel/team/provider logos are not rendered in Live TV, Catchup, Sports, EPG, Global Search, or other browsing lists.
- Movie/series posters remain supported as content artwork.

## UI direction
The home interface uses the SE layout with a **Main Sidebar** and **Category Sidebar**, with the content area on the right. Movies and Series keep their category search/navigation panels.

## Playback
The project retains Orbital's Media3/ExoPlayer + FFmpeg playback stack as the Android playback foundation.

## Build
Requires JDK 17+ and an Android SDK compatible with compile SDK 35.

```bash
./gradlew :app:assembleRelease
```

The GitHub Actions workflow in `.github/workflows/build-apk.yml` performs the same single-module release build and uploads the generated APK as `SE-v10.1.0-APK`.
