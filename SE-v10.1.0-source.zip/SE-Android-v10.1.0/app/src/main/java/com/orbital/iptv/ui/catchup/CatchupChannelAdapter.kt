package com.orbital.iptv.ui.catchup

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.orbital.iptv.data.model.LiveStream
import com.orbital.iptv.databinding.ItemCatchupChannelBinding
import com.orbital.iptv.utils.ThemeManager

class CatchupChannelAdapter(
    private val context: Context,
    private val onClick: (LiveStream) -> Unit
) : RecyclerView.Adapter<CatchupChannelAdapter.VH>() {

    var items: List<LiveStream> = emptyList()
        set(value) { field = value; notifyDataSetChanged() }

    inner class VH(val binding: ItemCatchupChannelBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemCatchupChannelBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val ch = items[position]
        holder.binding.tvChannelName.text = ch.name
        val days = ch.tvArchiveDuration ?: 0
        holder.binding.tvArchiveBadge.text = if (days > 0) "${days}D" else "LIVE"

        val p = ThemeManager.palette()
        val base = if (position % 2 == 0) p.bgMid else p.bgPrimary
        val density = holder.binding.root.resources.displayMetrics.density
        holder.binding.root.background = ThemeManager.focusRowDrawable(density, base, false)
        holder.binding.root.setOnFocusChangeListener { _, hasFocus ->
            holder.binding.root.background = ThemeManager.focusRowDrawable(density, base, hasFocus)
        }
        holder.binding.root.setOnClickListener { onClick(ch) }
    }
}
