package com.orbital.iptv.ui.series

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.orbital.iptv.data.model.Episode
import com.orbital.iptv.databinding.ItemEpisodeBinding
import com.orbital.iptv.utils.ThemeManager

class EpisodeAdapter(
    private val onPlay: (Episode) -> Unit,
    private val onLongPress: (Episode) -> Unit = {}
) : RecyclerView.Adapter<EpisodeAdapter.VH>() {

    private var items: List<Episode> = emptyList()
    private var selectedPosition = -1

    fun submitList(list: List<Episode>) {
        items = list
        selectedPosition = -1
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemEpisodeBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(items[position], position)

    override fun getItemCount() = items.size

    inner class VH(private val b: ItemEpisodeBinding) : RecyclerView.ViewHolder(b.root) {

        fun bind(ep: Episode, position: Int) {
            val epNum = ep.episodeNum ?: (position + 1)
            b.tvEpNum.text = "E%02d".format(epNum)
            b.tvEpTitle.text = ep.title?.takeIf { it.isNotBlank() } ?: "Episode $epNum"
            b.tvEpDuration.text = ep.info?.duration?.takeIf { it.isNotBlank() } ?: ""

            applyColors(position, focused = false, selected = position == selectedPosition)

            b.root.setOnClickListener {
                val pos = bindingAdapterPosition
                if (pos == RecyclerView.NO_POSITION) return@setOnClickListener
                val old = selectedPosition
                selectedPosition = pos
                if (old >= 0) notifyItemChanged(old)
                notifyItemChanged(pos)
                onPlay(ep)
            }
            b.root.setOnLongClickListener {
                val pos = bindingAdapterPosition
                if (pos != RecyclerView.NO_POSITION) onLongPress(items[pos])
                true
            }

            b.root.setOnFocusChangeListener { _, hasFocus ->
                val pos = bindingAdapterPosition
                if (pos == RecyclerView.NO_POSITION) return@setOnFocusChangeListener
                applyColors(pos, focused = hasFocus, selected = pos == selectedPosition)
            }
        }

        private fun applyColors(position: Int, focused: Boolean, selected: Boolean) {
            val p = ThemeManager.palette()
            val baseBg = when {
                selected -> p.highlight
                position % 2 == 0 -> p.rowEven
                else -> p.rowOdd
            }
            val density = b.root.resources.displayMetrics.density
            val focusFill = if (selected) p.highlight else p.focus
            b.root.background = ThemeManager.focusRowDrawable(density, baseBg, focused, focusFillColor = focusFill)
            b.tvEpNum.setTextColor(if (selected) 0xFF05040A.toInt() else p.accent)
            b.tvEpTitle.setTextColor(if (selected) 0xFF05040A.toInt() else p.tabTextOnSelected)
            b.tvEpDuration.setTextColor(if (selected) 0xFF05040A.toInt() else 0xFF8A94B4.toInt())
            b.btnPlayEp.background = ThemeManager.hudButtonDrawable(density)
            b.btnPlayEp.setTextColor(if (selected) 0xFFFFFFFF.toInt() else p.accent)
        }
    }
}
