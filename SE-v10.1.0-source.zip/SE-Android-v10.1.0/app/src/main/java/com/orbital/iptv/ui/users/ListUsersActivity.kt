package com.orbital.iptv.ui.users

import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.orbital.iptv.R
import com.orbital.iptv.data.model.ServerProfile
import com.orbital.iptv.data.repository.XtreamRepository
import com.orbital.iptv.databinding.ActivityListUsersBinding
import com.orbital.iptv.utils.MainSidebarController
import com.orbital.iptv.utils.PrefsManager
import com.orbital.iptv.utils.ThemeManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ListUsersActivity : AppCompatActivity() {
    private lateinit var binding: ActivityListUsersBinding
    private val repository = XtreamRepository()
    private val dateFormats = listOf(
        SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.US),
        SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.US)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeManager.load(this)
        binding = ActivityListUsersBinding.inflate(layoutInflater)
        setContentView(binding.root)
        MainSidebarController.setup(this, binding.root, MainSidebarController.Section.LIST_USERS)
        binding.btnRefresh.setOnClickListener { loadUsers() }
        loadUsers()
    }

    override fun onResume() {
        super.onResume()
        if (::binding.isInitialized) loadUsers()
    }

    private fun loadUsers() {
        val profiles = PrefsManager.getProfiles(this)
        val activeId = PrefsManager.getActiveProfileId(this)
        binding.progressBar.visibility = if (profiles.isEmpty()) View.GONE else View.VISIBLE
        binding.tvEmpty.visibility = if (profiles.isEmpty()) View.VISIBLE else View.GONE
        binding.tvEmpty.text = if (profiles.isEmpty()) "NO SAVED USERS" else ""
        binding.container.removeAllViews()
        if (profiles.isEmpty()) return

        lifecycleScope.launch {
            val cards = profiles.map { profile ->
                async(Dispatchers.IO) {
                    val info = repository.getServerInfo(profile.serverUrl, profile.username, profile.password).getOrNull()
                    UserRow(
                        profile = profile,
                        active = profile.id == activeId,
                        status = info?.userInfo?.status,
                        expDate = info?.userInfo?.expDate
                    )
                }
            }.awaitAll()
            binding.progressBar.visibility = View.GONE
            cards.forEach { addRow(it) }
        }
    }

    private fun addRow(row: UserRow) {
        val p = ThemeManager.palette()
        val density = resources.displayMetrics.density
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((14*density).toInt(), (10*density).toInt(), (14*density).toInt(), (10*density).toInt())
            background = ThemeManager.roundedBg(if (row.active) p.highlight else p.bgMid, density)
            isClickable = true
            isFocusable = true
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).also {
                it.setMargins((6*density).toInt(), (5*density).toInt(), (6*density).toInt(), (5*density).toInt())
            }
            setOnFocusChangeListener { v, hasFocus ->
                v.background = if (hasFocus) ThemeManager.focusRowDrawable(density, p.bgMid, true, focusFillColor = p.focus)
                else ThemeManager.roundedBg(if (row.active) p.highlight else p.bgMid, density)
            }
            setOnClickListener {
                if (!row.active) {
                    PrefsManager.setActiveProfile(this@ListUsersActivity, row.profile.id)
                    Toast.makeText(this@ListUsersActivity, "ACTIVE USER: ${row.profile.name}", Toast.LENGTH_SHORT).show()
                    loadUsers()
                }
            }
        }

        val title = TextView(this).apply {
            text = "${if (row.active) "●  " else "○  "}${row.profile.name}"
            textSize = 15f
            setTextColor(if (row.active) 0xFF000000.toInt() else Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val server = TextView(this).apply {
            text = "${row.profile.username}  •  ${row.profile.serverUrl}"
            textSize = 10f
            setTextColor(if (row.active) 0xFF202020.toInt() else Color.WHITE)
        }
        val status = TextView(this).apply {
            text = "STATUS: ${row.status ?: "UNKNOWN".uppercase()}    EXPIRATION DATE: ${formatExpiry(row.expDate)}"
            textSize = 10f
            setTextColor(if (row.active) 0xFF303030.toInt() else p.accent)
        }
        card.addView(title)
        card.addView(server, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).also { it.topMargin=(3*density).toInt() })
        card.addView(status, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).also { it.topMargin=(5*density).toInt() })
        binding.container.addView(card)
    }

    private fun formatExpiry(raw: String?): String {
        val seconds = raw?.trim()?.toLongOrNull() ?: return "UNKNOWN"
        if (seconds <= 0L) return "NO EXPIRATION"
        val millis = if (seconds < 10_000_000_000L) seconds * 1000L else seconds
        return dateFormats.firstOrNull()?.format(Date(millis)) ?: "UNKNOWN"
    }

    private data class UserRow(
        val profile: ServerProfile,
        val active: Boolean,
        val status: String?,
        val expDate: String?
    )
}
