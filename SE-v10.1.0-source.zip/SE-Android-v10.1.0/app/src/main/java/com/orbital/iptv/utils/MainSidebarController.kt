package com.orbital.iptv.utils

import android.app.Activity
import android.content.Intent
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.orbital.iptv.R
import com.orbital.iptv.ui.favourites.FavouritesActivity
import com.orbital.iptv.ui.home.HomeActivity
import com.orbital.iptv.ui.search.GlobalSearchActivity
import com.orbital.iptv.ui.series.SeriesActivity
import com.orbital.iptv.ui.vod.VodActivity

/** Shared SE main navigation used by every primary content screen. */
object MainSidebarController {
    enum class Section { LIVE_TV, MOVIES, SERIES, FAVOURITES, SEARCH, SETTINGS, LIST_USERS }

    fun setup(
        activity: AppCompatActivity,
        root: View,
        selected: Section,
        onSettings: (() -> Unit)? = null
    ) {
        val items = listOf(
            Section.LIVE_TV to R.id.nav_live_tv,
            Section.MOVIES to R.id.nav_movies,
            Section.SERIES to R.id.nav_series,
            Section.FAVOURITES to R.id.nav_favourites,
            Section.SEARCH to R.id.nav_search,
            Section.SETTINGS to R.id.nav_settings,
            Section.LIST_USERS to R.id.nav_list_users
        )

        val density = activity.resources.displayMetrics.density
        val palette = ThemeManager.palette()

        items.forEach { (section, id) ->
            val view = root.findViewById<TextView>(id) ?: return@forEach
            val isSelected = section == selected
            view.background = ThemeManager.navTabDrawable(density, selected = isSelected)
            view.setTextColor(if (isSelected) palette.tabTextOnSelected else 0xFFFFFFFF.toInt())
            view.setOnFocusChangeListener { v, hasFocus ->
                v.background = ThemeManager.focusRowDrawable(
                    density,
                    palette.bgHeader,
                    hasFocus,
                    focusFillColor = if (isSelected) palette.tabSelected else palette.focus
                )
                (v as? TextView)?.setTextColor(
                    if (hasFocus || isSelected) palette.accent else 0xFFFFFFFF.toInt()
                )
            }
            view.setOnClickListener {
                if (section == selected && section != Section.SETTINGS) return@setOnClickListener
                when (section) {
                    Section.LIVE_TV -> go(activity, HomeActivity::class.java)
                    Section.MOVIES -> go(activity, VodActivity::class.java)
                    Section.SERIES -> go(activity, SeriesActivity::class.java)
                    Section.FAVOURITES -> go(activity, FavouritesActivity::class.java)
                    Section.SEARCH -> go(activity, GlobalSearchActivity::class.java)
                    Section.SETTINGS -> {
                        if (onSettings != null) onSettings()
                        else activity.startActivity(Intent(activity, HomeActivity::class.java).apply {
                            addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                            putExtra(HomeActivity.EXTRA_OPEN_SETTINGS, true)
                        })
                    }
                    Section.LIST_USERS -> go(activity, com.orbital.iptv.ui.users.ListUsersActivity::class.java)
                }
            }
        }

        val exit = root.findViewById<TextView>(R.id.nav_exit)
        exit?.let { view ->
            view.background = ThemeManager.navTabDrawable(density, selected = false)
            view.setTextColor(0xFFFFFFFF.toInt())
            view.setOnFocusChangeListener { v, hasFocus ->
                v.background = ThemeManager.focusRowDrawable(
                    density, palette.bgHeader, hasFocus, focusFillColor = palette.focus
                )
                (v as? TextView)?.setTextColor(if (hasFocus) palette.accent else 0xFFFFFFFF.toInt())
            }
            view.setOnClickListener { confirmExit(activity) }
        }
    }

    private fun <T : Activity> go(activity: AppCompatActivity, target: Class<T>) {
        if (activity::class.java == target) return
        activity.startActivity(Intent(activity, target).apply {
            addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        })
    }

    private fun confirmExit(activity: Activity) {
        AlertDialog.Builder(activity, ThemeManager.dialogStyle())
            .setTitle("EXIT SE IPTV PLAYER")
            .setMessage("Are you sure you want to exit?")
            .setPositiveButton("EXIT") { _, _ -> activity.finishAffinity() }
            .setNegativeButton("CANCEL", null)
            .show()
    }
}
