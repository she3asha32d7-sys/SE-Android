# SE IPTV Player v3.0.1

Source base: M3UAndroid Smartphone v1.15.0
Target: Android Mobile (phone/tablet)

## First SE layer
- SE app name and package identity
- SE launcher and splash artwork
- SE-branded top bar
- SE-styled mobile navigation colors
- Home filters for All / Live TV / Movies / Series
- Dark SE accent default

## Playback
The upstream Media3/ExoPlayer and extended decoder architecture is preserved in this first migration pass.
