# SEAndroid_v2.0.1

Final Android Studio source for the SE IPTV Player modification set.

See `FINAL_33_AUDIT.md` for the 33-point implementation audit and validation notes.

Build metadata: versionName 2.0.1 / versionCode 201.
About screen: V10.0.1.
Application ID: com.se.iptv.player.
