package com.orbital.iptv.recording

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.orbital.iptv.R
import com.orbital.iptv.databinding.ActivityRecordingsBinding
import com.orbital.iptv.ui.player.PlayerActivity
import com.orbital.iptv.utils.MainSidebarController
import com.orbital.iptv.utils.ThemeManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RecordingsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRecordingsBinding
    private val dao by lazy { RecordingDatabase.get(this).dao() }
    private lateinit var adapter: RecordingAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        ThemeManager.load(this)
        binding = ActivityRecordingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        MainSidebarController.setup(this, binding.root, MainSidebarController.Section.RECORDS)
        adapter = RecordingAdapter(::playRecording, ::removeFromList, ::deleteFile)
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter
        updateClock()
        observeRecordings()
    }

    private fun updateClock() {
        val f = SimpleDateFormat("dd/MM/yyyy  hh:mm a", Locale.US)
        binding.tvHeaderDatetime.text = f.format(Date()).uppercase(Locale.US)
        binding.tvHeaderDatetime.postDelayed({ if (!isFinishing) updateClock() }, 30000L)
    }

    private fun observeRecordings() {
        lifecycleScope.launch {
            dao.allFlow().collectLatest { all ->
                val filtered = all.filter { it.status != RecordingStatus.SKIPPED }
                adapter.submitList(filtered)
                binding.tvEmpty.visibility = if (filtered.isEmpty()) View.VISIBLE else View.GONE
                binding.recyclerView.visibility = if (filtered.isEmpty()) View.GONE else View.VISIBLE
            }
        }
    }

    private fun playRecording(rec: RecordingEntity) {
        if (rec.filePath.isBlank() || !File(rec.filePath).exists()) {
            Toast.makeText(this, "RECORDING FILE NOT FOUND", Toast.LENGTH_SHORT).show(); return
        }
        startActivity(Intent(this, PlayerActivity::class.java).apply {
            putExtra(PlayerActivity.EXTRA_STREAM_URL, "file://${rec.filePath}")
            putExtra(PlayerActivity.EXTRA_CHANNEL_NAME, "${rec.channelName} — ${rec.epgTitle}")
            putExtra(PlayerActivity.EXTRA_STREAM_ID, -1)
            putExtra(PlayerActivity.EXTRA_IS_LIVE, false)
        })
    }

    private fun removeFromList(rec: RecordingEntity) {
        lifecycleScope.launch(Dispatchers.IO) { dao.delete(rec) }
    }

    private fun deleteFile(rec: RecordingEntity) {
        AlertDialog.Builder(this, ThemeManager.dialogStyle())
            .setTitle("DELETE FILE")
            .setMessage("Delete this recorded file?")
            .setPositiveButton("Yes") { _, _ ->
                lifecycleScope.launch(Dispatchers.IO) {
                    if (rec.filePath.isNotBlank()) File(rec.filePath).delete()
                    dao.delete(rec)
                }
            }
            .setNegativeButton("No", null)
            .show()
    }
}

class RecordingAdapter(
    private val onPlay: (RecordingEntity) -> Unit,
    private val onRemove: (RecordingEntity) -> Unit,
    private val onDeleteFile: (RecordingEntity) -> Unit
) : ListAdapter<RecordingEntity, RecordingAdapter.VH>(DIFF) {
    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<RecordingEntity>() {
            override fun areItemsTheSame(a: RecordingEntity, b: RecordingEntity) = a.id == b.id
            override fun areContentsTheSame(a: RecordingEntity, b: RecordingEntity) = a == b
        }
    }

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvChannel: TextView = view.findViewById(R.id.tv_channel)
        val tvStatus: TextView = view.findViewById(R.id.tv_status)
        val tvTitle: TextView = view.findViewById(R.id.tv_title)
        val tvTime: TextView = view.findViewById(R.id.tv_time)
        val btnOpen: Button = view.findViewById(R.id.btn_open)
        val btnFind: Button = view.findViewById(R.id.btn_find_location)
        val btnCopy: Button = view.findViewById(R.id.btn_copy)
        val btnRemove: Button = view.findViewById(R.id.btn_remove)
        val btnDelete: Button = view.findViewById(R.id.btn_delete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_recording, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val rec = getItem(position)
        holder.tvChannel.text = rec.channelName.uppercase(Locale.US)
        holder.tvTitle.text = rec.epgTitle.ifBlank { "Recording" }
        holder.tvTime.text = SimpleDateFormat("dd/MM/yyyy  HH:mm", Locale.US).format(Date(rec.scheduledStart))
        holder.tvStatus.text = when (rec.status) {
            RecordingStatus.RECORDING -> "● REC"
            RecordingStatus.COMPLETED -> "COMPLETED"
            RecordingStatus.FAILED -> "FAILED"
            RecordingStatus.SCHEDULED -> "SCHEDULED"
            RecordingStatus.SKIPPED -> "SKIPPED"
        }
        val canOpen = rec.filePath.isNotBlank() && File(rec.filePath).exists() && rec.status == RecordingStatus.COMPLETED
        holder.btnOpen.isEnabled = canOpen
        holder.btnOpen.setOnClickListener { if (canOpen) onPlay(rec) else Toast.makeText(holder.itemView.context, "FILE NOT READY", Toast.LENGTH_SHORT).show() }
        holder.btnFind.setOnClickListener { Toast.makeText(holder.itemView.context, rec.filePath.ifBlank { "NO FILE LOCATION" }, Toast.LENGTH_LONG).show() }
        holder.btnCopy.setOnClickListener {
            val cm = holder.itemView.context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("FILE", rec.filePath))
            Toast.makeText(holder.itemView.context, "FILE PATH COPIED", Toast.LENGTH_SHORT).show()
        }
        holder.btnRemove.setOnClickListener { onRemove(rec) }
        holder.btnDelete.setOnClickListener { onDeleteFile(rec) }
    }
}
