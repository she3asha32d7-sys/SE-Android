package com.orbital.iptv.ui.downloads
import android.content.*; import android.net.Uri; import android.os.Bundle; import android.provider.DocumentsContract; import android.widget.*; import androidx.appcompat.app.AppCompatActivity; import androidx.recyclerview.widget.*; import com.orbital.iptv.databinding.ActivityDownloadsBinding; import com.orbital.iptv.databinding.ItemDownloadBinding; import com.orbital.iptv.utils.*; import java.io.File
class DownloadsActivity:AppCompatActivity(){
 private lateinit var b:ActivityDownloadsBinding; private lateinit var a:Adapter
 override fun onCreate(x:Bundle?){super.onCreate(x);b=ActivityDownloadsBinding.inflate(layoutInflater);setContentView(b.root);ThemeManager.load(this);MainSidebarController.setup(this,b.root,MainSidebarController.Section.DOWNLOADS);a=Adapter();b.recyclerDownloads.layoutManager=LinearLayoutManager(this);b.recyclerDownloads.adapter=a;b.btnChangeLocation.setOnClickListener{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION),9001)};refresh()}
 override fun onResume(){super.onResume();if(::a.isInitialized)refresh()}
 override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d);if(r==9001&&c==RESULT_OK){d?.data?.let{contentResolver.takePersistableUriPermission(it,d.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION));DownloadStore.setFolder(this,it.toString());Toast.makeText(this,"DOWNLOAD LOCATION SAVED",Toast.LENGTH_SHORT).show()}}}
 private fun refresh(){val l=DownloadStore.all(this);a.submit(l);b.tvEmpty.visibility=if(l.isEmpty())android.view.View.VISIBLE else android.view.View.GONE;b.recyclerDownloads.visibility=if(l.isEmpty())android.view.View.GONE else android.view.View.VISIBLE}
 inner class Adapter:RecyclerView.Adapter<Adapter.VH>(){
  var items=listOf<DownloadItem>(); fun submit(l:List<DownloadItem>){items=l;notifyDataSetChanged()}
  inner class VH(v:android.view.View):RecyclerView.ViewHolder(v){val b=ItemDownloadBinding.bind(v)}
  override fun onCreateViewHolder(p:android.view.ViewGroup,t:Int)=VH(layoutInflater.inflate(com.orbital.iptv.R.layout.item_download,p,false))
  override fun getItemCount()=items.size
  override fun onBindViewHolder(h:VH,pos:Int){val i=items[pos];h.b.tvTitle.text=i.title;h.b.tvStatus.text=i.status;h.b.btnOpen.setOnClickListener{open(i)};h.b.btnFindLocation.setOnClickListener{Toast.makeText(this@DownloadsActivity,"${i.uri}",Toast.LENGTH_LONG).show()};h.b.btnRemove.setOnClickListener{DownloadStore.remove(this@DownloadsActivity,i.id);refresh()};h.b.btnDelete.setOnClickListener{deleteFile(i)};h.b.btnCopy.setOnClickListener{(getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(android.content.ClipData.newPlainText("FILE",i.uri))}}
  private fun open(i:DownloadItem){try{val uri=Uri.parse(i.uri);if(uri.scheme==null)return;startActivity(Intent(Intent.ACTION_VIEW).apply{setDataAndType(uri,"video/*");addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)})}catch(_:Exception){Toast.makeText(this@DownloadsActivity,"NO PLAYER FOUND",Toast.LENGTH_SHORT).show()}}
  private fun deleteFile(i:DownloadItem){try{val uri=Uri.parse(i.uri);when(uri.scheme){"file"->File(uri.path?:"").delete();"content"->DocumentsContract.deleteDocument(contentResolver,uri)} }catch(_:Exception){};DownloadStore.remove(this@DownloadsActivity,i.id);refresh()}
 }
}
