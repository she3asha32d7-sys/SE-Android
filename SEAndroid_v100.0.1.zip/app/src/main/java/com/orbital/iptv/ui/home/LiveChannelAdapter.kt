package com.orbital.iptv.ui.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.orbital.iptv.R
import com.orbital.iptv.data.model.LiveStream
import com.orbital.iptv.databinding.ItemLiveChannelBinding
import com.orbital.iptv.utils.ThemeManager
import com.orbital.iptv.utils.FavouritesManager
import com.orbital.iptv.data.api.ApiClient
import com.orbital.iptv.utils.PrefsManager

class LiveChannelAdapter(
    private val onClick: (LiveStream) -> Unit
) : RecyclerView.Adapter<LiveChannelAdapter.VH>() {
    private var items: List<LiveStream> = emptyList()

    fun submitList(list: List<LiveStream>) {
        items = list
        notifyDataSetChanged()
    }

    fun notifyStreamChanged(streamId: Int) {
        val i = items.indexOfFirst { it.streamId == streamId }
        if (i >= 0) notifyItemChanged(i)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemLiveChannelBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(items[position])
    override fun getItemCount() = items.size

    inner class VH(private val b: ItemLiveChannelBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(channel: LiveStream) {
            b.tvNumber.text = channel.num?.let { String.format("%03d", it) } ?: String.format("%03d", bindingAdapterPosition + 1)
            b.tvName.text = channel.name
            b.tvNow.text = channel.epgNow?.takeIf { it.isNotBlank() } ?: "NOW PLAYING"
            val context = b.root.context
            fun updateFav() {
                val fav = FavouritesManager.containsLive(context, channel.streamId)
                b.btnFav.text = if (fav) "♥" else "♡"
                b.btnFav.setTextColor(if (fav) 0xFFFF3030.toInt() else 0xFFFFFFFF.toInt())
            }
            updateFav()
            b.btnFav.setOnClickListener {
                if (FavouritesManager.containsLive(context, channel.streamId)) {
                    FavouritesManager.removeLive(context, channel.streamId)
                } else {
                    run {
                    val profile = PrefsManager.getActiveProfile(context)
                    val url = channel.directSource?.takeIf { it.isNotBlank() } ?: profile?.let { ApiClient.buildStreamUrl(it.serverUrl, it.username, it.password, channel.streamId) } ?: ""
                    FavouritesManager.addLiveChannel(context, channel.name, channel.streamId, url, channel.streamIcon)
                }
                }
                updateFav()
            }
            val d = b.root.resources.displayMetrics.density
            b.root.setOnClickListener { onClick(channel) }
            b.root.setOnFocusChangeListener { _, hasFocus ->
                val p = ThemeManager.palette()
                if (hasFocus) {
                    b.root.background = ThemeManager.focusRowDrawable(d, p.bgMid, true, focusFillColor = p.focus)
                    b.root.scaleX = 1.035f; b.root.scaleY = 1.035f; b.root.elevation = 8f
                    b.tvName.setTextColor(p.accent)
                } else {
                    b.root.background = ThemeManager.roundedBg(p.bgMid, d)
                    b.root.scaleX = 1f; b.root.scaleY = 1f; b.root.elevation = 0f
                    b.tvName.setTextColor(0xFFFFFFFF.toInt())
                }
            }
            b.root.background = ThemeManager.roundedBg(ThemeManager.palette().bgMid, d)
        }
    }
}
