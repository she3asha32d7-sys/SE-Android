package com.orbital.iptv.ui.settings

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.orbital.iptv.databinding.ActivitySettingsBinding
import com.orbital.iptv.data.api.ApiClient
import com.orbital.iptv.utils.FavouritesManager
import com.orbital.iptv.utils.PrefsManager
import com.orbital.iptv.utils.WatchHistoryManager
import com.orbital.iptv.utils.MainSidebarController
import com.orbital.iptv.utils.ThemeManager
import java.text.SimpleDateFormat
import java.util.*
import androidx.work.WorkManager

class SettingsActivity : AppCompatActivity() {
    private lateinit var b: ActivitySettingsBinding
    private val dateFmt = SimpleDateFormat("dd/MM/yyyy  hh:mm a", Locale.US)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ThemeManager.load(this)
        b = ActivitySettingsBinding.inflate(layoutInflater); setContentView(b.root)
        MainSidebarController.setup(this, b.root, MainSidebarController.Section.SETTINGS)
        b.rgLiveFormat.check(if (PrefsManager.getLiveFormat(this).equals("mpegts", true) || PrefsManager.getLiveFormat(this).equals("ts", true)) b.rbMpegts.id else b.rbHls.id)
        b.rgLiveFormat.setOnCheckedChangeListener { _, id -> ApiClient.liveFormat = if (id == b.rbMpegts.id) "ts" else "m3u8"; PrefsManager.setLiveFormat(this, ApiClient.liveFormat) }
        b.switchAutoRotate.isChecked = PrefsManager.isAutoRotateEnabled(this)
        b.switchAutoRotate.setOnCheckedChangeListener { _, on -> PrefsManager.setAutoRotateEnabled(this,on); requestedOrientation = if(on) android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE }
        val speeds = mapOf(b.speed05 to .5f,b.speed15 to 1.5f,b.speed2 to 2f,b.speed3 to 3f,b.speed4 to 4f)
        val saved = PrefsManager.getPlaybackSpeed(this); (speeds.minByOrNull { kotlin.math.abs(it.value-saved) }?.key ?: b.speed15).isChecked = true
        b.rgSpeed.setOnCheckedChangeListener { _, id -> speeds.entries.firstOrNull { it.key.id==id }?.let { PrefsManager.setPlaybackSpeed(this,it.value) } }
        b.btnClearHistory.setOnClickListener { confirm("Do You Want To Clear Watch History") { WatchHistoryManager.clear(this) } }
        b.btnClearFavorite.setOnClickListener { confirm("Do You Want To Clear Favorite") { FavouritesManager.clear(this) } }
        b.btnResetApp.setOnClickListener { confirm("Do You Want To Reset App") { resetAppData() } }
        b.root.post { updateDateTime() }
    }
    private fun resetAppData() {
        WorkManager.getInstance(this).cancelAllWork()
        PrefsManager.clearCredentials(this)
        FavouritesManager.clear(this)
        WatchHistoryManager.clear(this)
        getSharedPreferences("se_downloads", MODE_PRIVATE).edit().clear().apply()
        getSharedPreferences("se_theme", MODE_PRIVATE).edit().clear().apply()
        getSharedPreferences("se_category_prefs", MODE_PRIVATE).edit().clear().apply()
        ApiClient.liveFormat = "m3u8"
        deleteDatabase("se_iptv_recordings.db")
        fun wipe(f: java.io.File?) {
            if (f == null || !f.exists()) return
            if (f.isDirectory) f.listFiles()?.forEach(::wipe)
            f.delete()
        }
        wipe(filesDir)
        externalCacheDir?.deleteRecursively()
        getExternalFilesDirs(null).forEach { wipe(it) }
        startActivity(Intent(this, com.orbital.iptv.ui.login.LoginActivity::class.java).putExtra("skip_auto", true))
        finishAffinity()
    }
    private fun updateDateTime() { if (!::b.isInitialized) return; b.tvHeaderDatetime.text = dateFmt.format(Date()).uppercase(Locale.US); b.tvHeaderDatetime.postDelayed({ updateDateTime() },30000) }
    private fun confirm(title:String, yes:()->Unit) { AlertDialog.Builder(this).setTitle(title).setPositiveButton("Yes"){_,_->yes()}.setNegativeButton("No",null).show() }
    override fun onDestroy(){ super.onDestroy() }
}
