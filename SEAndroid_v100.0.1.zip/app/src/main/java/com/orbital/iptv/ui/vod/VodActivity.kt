package com.orbital.iptv.ui.vod

import android.content.Intent
import com.orbital.iptv.ui.series.SeriesActivity
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import com.orbital.iptv.data.model.VodCategory
import com.orbital.iptv.data.model.VodStream
import com.orbital.iptv.databinding.ActivityVodBinding
import com.orbital.iptv.data.model.FavType
import com.orbital.iptv.data.repository.XtreamRepository
import com.orbital.iptv.utils.ContentCache
import com.orbital.iptv.utils.FavouritesManager
import com.orbital.iptv.utils.PlayerLauncher
import com.orbital.iptv.utils.PrefsManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import com.orbital.iptv.utils.ThemeManager
import com.orbital.iptv.utils.MainSidebarController
import com.orbital.iptv.utils.WatchHistoryManager
import com.orbital.iptv.ui.settings.SettingsActivity
import com.orbital.iptv.ui.settings.SettingsActivity.Section

class VodActivity : AppCompatActivity() {

    private lateinit var binding: ActivityVodBinding
    private lateinit var viewModel: VodViewModel
    private lateinit var adapter: VodAdapter
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private var allMovies: List<VodStream> = emptyList()
    private var isSearchActive = false
    private var showingContinue = false
    private var showingFavourites = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        supportActionBar?.hide()
        binding = ActivityVodBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ThemeManager.load(this)
        val p = ThemeManager.palette()
        binding.root.setBackgroundColor(p.bgPrimary)
        binding.layoutHeader?.setBackgroundColor(p.bgHeader)
        binding.viewAccent?.setBackgroundColor(p.accent)
        startHeaderClock()

        viewModel = ViewModelProvider(this)[VodViewModel::class.java]
        binding.btnBack.visibility = View.GONE
        MainSidebarController.setup(this, binding.root, Section.MOVIES, onSettings = { startActivity(Intent(this, SettingsActivity::class.java)) })
        binding.btnBack.setOnFocusChangeListener { _, hasFocus ->
            val d = resources.displayMetrics.density
            binding.btnBack.background = ThemeManager.focusRowDrawable(d, 0xFF1E3D72.toInt(), hasFocus)
        }

        adapter = VodAdapter(this) { movie -> onMovieSelected(movie) }
        binding.rvMovies.apply {
            this.adapter = this@VodActivity.adapter
            layoutManager = GridLayoutManager(this@VodActivity, 3)
        }

        setupSearch()
        // Search stays in the content header; typing filters only movie content.

        onBackPressedDispatcher.addCallback(this, object : androidx.activity.OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val q = binding.etSearch.text?.toString()?.trim().orEmpty()
                if (q.isNotEmpty()) {
                    binding.etSearch.text?.clear()
                    binding.etSearch.clearFocus()
                    binding.rvMovies.requestFocus()
                    return
                }
                if (binding.rvMovies.hasFocus()) {
                    binding.catContainer.getChildAt(0).requestFocus()
                    return
                }
                isEnabled = false
                onBackPressedDispatcher.onBackPressed()
                isEnabled = true
            }
        })


        viewModel.uiState.observe(this) { state ->
            binding.progressBar.visibility = if (state.isLoading) View.VISIBLE else View.GONE
            state.error?.let {
                binding.tvError.text = it.uppercase(); binding.tvError.visibility = View.VISIBLE
            } ?: run { binding.tvError.visibility = View.GONE }

            if (!isSearchActive && !showingContinue && !showingFavourites) {
                adapter.submitList(state.movies)
                binding.tvMovieCount.text = "${state.movies.size} TITLES"
            }
            if (state.categories.isNotEmpty()) buildCategoryMenu(state.categories, state.selectedCategory)
            if (!showingContinue && !showingFavourites) state.selectedCategory?.let { binding.tvCurrentCategory.text = it.categoryName }
        }

        val creds = PrefsManager.getCredentials(this) ?: run { finish(); return }
        viewModel.loadCategories(creds.serverUrl, creds.username, creds.password)

        scope.launch {
            val cached = ContentCache.getMovies(this@VodActivity, creds.serverUrl)
            if (cached != null) {
                allMovies = cached
            } else {
                // Stream straight to disk (not through Retrofit/Gson) to avoid OOM on large
                // VOD catalogs, then read back via streaming JsonReader.
                ContentCache.downloadAndSaveMovies(this@VodActivity, creds.serverUrl, creds.username, creds.password)
                ContentCache.getMovies(this@VodActivity, creds.serverUrl)?.let { allMovies = it }
            }
        }
    }

    private fun startHeaderClock() {
        val fmt=java.text.SimpleDateFormat("dd/MM/yyyy  hh:mm a", java.util.Locale.US)
        val v=binding.root.findViewById<TextView>(com.orbital.iptv.com.orbital.iptv.R.id.tv_header_datetime)
        fun tick(){ v?.text=fmt.format(java.util.Date()).uppercase(); v?.postDelayed({tick()},30000) }
        tick()
    }

    private fun setupSearch() {
        binding.etSearch.setOnKeyListener { _, keyCode, event ->
            if (keyCode == android.view.KeyEvent.KEYCODE_DPAD_DOWN &&
                event.action == android.view.KeyEvent.ACTION_DOWN) {
                for (i in 0 until binding.catContainer.childCount) {
                    val child = binding.catContainer.getChildAt(i)
                    if (child.isFocusable) { child.requestFocus(); break }
                }
                true
            } else false
        }
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val query = s?.toString()?.trim() ?: ""
                if (query.length < 2) {
                    isSearchActive = false
                    when {
                        showingFavourites -> showFavouritesMovies()
                        showingContinue   -> showContinueWatching()
                        else -> {
                            val current = viewModel.uiState.value?.movies ?: emptyList()
                            adapter.submitList(current)
                            binding.tvMovieCount.text = "${current.size} TITLES"
                            binding.tvCurrentCategory.text = viewModel.uiState.value?.selectedCategory?.categoryName ?: "MOVIES"
                        }
                    }
                } else {
                    isSearchActive = true
                    val source = allMovies.ifEmpty { viewModel.uiState.value?.movies ?: emptyList() }
                    val filtered = source.filter { it.name.contains(query, ignoreCase = true) }
                    adapter.submitList(filtered)
                    binding.tvMovieCount.text = "${filtered.size} RESULTS"
                    binding.tvCurrentCategory.text = "SEARCH: $query"
                }
            }
        })
    }

    private fun buildCategoryMenu(categories: List<VodCategory>, selected: VodCategory?) {
        val container = binding.catContainer
        while (container.childCount > 1) container.removeViewAt(1)

        val p = ThemeManager.palette()
        val density = resources.displayMetrics.density
        val rowH = (46 * density).toInt()
        val pad  = (16 * density).toInt()
        val marginPx = (p.itemMarginDp * density).toInt()

        val allFavs = FavouritesManager.getAll(this)
        val favItems     = allFavs.filter { it.type == FavType.MOVIE && !it.hasResume }
        val continueItems = allFavs.filter { it.hasResume && it.type == FavType.MOVIE }

        if (favItems.isNotEmpty()) {
            val isSel = showingFavourites
            container.addView(TextView(this).apply {
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, rowH)
                if (marginPx > 0) lp.setMargins(marginPx, marginPx / 2, marginPx, marginPx / 2)
                layoutParams = lp
                gravity = Gravity.CENTER_VERTICAL
                setPadding(pad, 0, 0, 0)
                text = "★ FAVOURITES"
                textSize = 13f
                typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
                isClickable = true; isFocusable = true
                background = ThemeManager.roundedBg(if (isSel) p.highlight else p.bgMid, density)
                setTextColor(if (isSel) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
                setOnFocusChangeListener { _, hasFocus ->
                    if (!isSel) background = ThemeManager.focusRowDrawable(density, p.bgMid, hasFocus)
                }
                setOnClickListener {
                    showingFavourites = true; showingContinue = false
                    binding.etSearch.text?.clear()
                    showFavouritesMovies()
                    buildCategoryMenu(categories, selected)
                }
            })
        }

        if (continueItems.isNotEmpty()) {
            val isSel = showingContinue
            container.addView(TextView(this).apply {
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, rowH)
                if (marginPx > 0) lp.setMargins(marginPx, marginPx / 2, marginPx, marginPx / 2)
                layoutParams = lp
                gravity = Gravity.CENTER_VERTICAL
                setPadding(pad, 0, 0, 0)
                text = "▶ CONTINUE WATCHING"
                textSize = 13f
                typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
                isClickable = true; isFocusable = true
                background = ThemeManager.roundedBg(if (isSel) p.highlight else p.bgMid, density)
                setTextColor(if (isSel) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
                setOnFocusChangeListener { _, hasFocus ->
                    if (!isSel) background = ThemeManager.focusRowDrawable(density, p.bgMid, hasFocus)
                }
                setOnClickListener {
                    showingContinue = true; showingFavourites = false
                    binding.etSearch.text?.clear()
                    showContinueWatching()
                    buildCategoryMenu(categories, selected)
                }
            })
        }

        val offset = (if (favItems.isNotEmpty()) 1 else 0) + (if (continueItems.isNotEmpty()) 1 else 0)
        categories.forEachIndexed { i, cat ->
            val isSelected = !showingContinue && !showingFavourites && cat.categoryId == selected?.categoryId
            val idx = i + offset
            val normalBg = if (idx % 2 == 0) p.bgMid else p.bgPrimary
            container.addView(TextView(this).apply {
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, rowH)
                if (marginPx > 0) lp.setMargins(marginPx, marginPx / 2, marginPx, marginPx / 2)
                layoutParams = lp
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                setPadding(pad, 0, 0, 0)
                text = cat.categoryName
                textSize = 13f
                typeface = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
                isClickable = true; isFocusable = true
                background = if (isSelected) ThemeManager.roundedBg(p.highlight, density) else ThemeManager.roundedBg(normalBg, density)
                setTextColor(if (isSelected) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
                setOnFocusChangeListener { _, hasFocus ->
                    if (!isSelected) background = ThemeManager.focusRowDrawable(density, normalBg, hasFocus)
                }
                setOnClickListener {
                    showingContinue = false; showingFavourites = false
                    binding.etSearch.text?.clear()
                    viewModel.selectCategory(cat)
                }
            })
        }
    }

    private fun showFavouritesMovies() {
        val favIds = FavouritesManager.getAll(this)
            .filter { it.type == FavType.MOVIE && !it.hasResume }
            .map { it.streamId }.toSet()
        val favMovies = allMovies.filter { it.streamId in favIds }
        adapter.submitList(favMovies)
        binding.tvMovieCount.text = "${favMovies.size} TITLES"
        binding.tvCurrentCategory.text = "FAVOURITES"
    }

    private fun showContinueWatching() {
        val continueItems = FavouritesManager.getAll(this).filter { it.hasResume && it.type == FavType.MOVIE }
        val resumeLabels = continueItems.associate { fav ->
            fav.streamId to "▶ FROM ${FavouritesManager.formatDuration(fav.resumePositionMs)} / ${FavouritesManager.formatDuration(fav.durationMs)}"
        }
        val resumeMovies = allMovies.filter { it.streamId in resumeLabels }
        adapter.submitList(resumeMovies, resumeLabels)
        binding.tvMovieCount.text = "${resumeMovies.size} TITLES"
        binding.tvCurrentCategory.text = "CONTINUE WATCHING"
    }

    private fun onMovieSelected(movie: VodStream) {
        val creds = viewModel.getCredentials() ?: return
        if (showingContinue) {
            val favId  = "movie_${movie.streamId}"
            val fav    = FavouritesManager.getById(this, favId)
            val vodUrl = XtreamRepository().buildVodUrl(
                creds.first, creds.second, creds.third,
                movie.streamId, movie.containerExtension ?: "mp4"
            )
            PlayerLauncher.launch(
                activity  = this,
                streamUrl = vodUrl,
                title     = movie.name,
                streamId  = movie.streamId,
                isLive    = false,
                favId     = favId,
                artUrl    = movie.streamIcon ?: "",
                resumeMs  = fav?.resumePositionMs ?: 0L
            )
            return
        }
        startActivity(Intent(this, MovieDetailActivity::class.java).apply {
            putExtra(MovieDetailActivity.EXTRA_STREAM_ID, movie.streamId)
            putExtra(MovieDetailActivity.EXTRA_STREAM_NAME, movie.name)
            putExtra(MovieDetailActivity.EXTRA_STREAM_ICON, movie.streamIcon ?: "")
            putExtra(MovieDetailActivity.EXTRA_CONTAINER_EXT, movie.containerExtension ?: "mp4")
            putExtra(MovieDetailActivity.EXTRA_RATING, movie.rating ?: "")
            putExtra(MovieDetailActivity.EXTRA_SERVER_URL, creds.first)
            putExtra(MovieDetailActivity.EXTRA_USERNAME, creds.second)
            putExtra(MovieDetailActivity.EXTRA_PASSWORD, creds.third)
        })
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}
