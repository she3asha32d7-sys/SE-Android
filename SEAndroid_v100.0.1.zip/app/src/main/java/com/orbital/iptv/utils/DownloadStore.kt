package com.orbital.iptv.utils

import android.content.Context
import androidx.work.OneTimeWorkRequest
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.util.UUID

data class DownloadItem(val id:String=UUID.randomUUID().toString(),val url:String,val title:String,val uri:String="",val status:String="QUEUED",val createdAt:Long=System.currentTimeMillis())
object DownloadStore {
 private const val P="se_downloads"; private const val K="items"; private const val F="folder_uri"; private val gson=Gson()
 private fun p(c:Context)=c.getSharedPreferences(P,0)
 fun all(c:Context)=try{gson.fromJson<List<DownloadItem>>(p(c).getString(K,null),object:TypeToken<List<DownloadItem>>(){}.type)?:emptyList()}catch(_:Exception){emptyList()}
 fun save(c:Context,i:DownloadItem){val l=all(c).filterNot{it.id==i.id}.toMutableList();l.add(0,i);p(c).edit().putString(K,gson.toJson(l)).apply()}
 fun remove(c:Context,id:String){p(c).edit().putString(K,gson.toJson(all(c).filterNot{it.id==id})).apply()}
 fun set(c:Context,id:String,status:String,uri:String?=null){all(c).find{it.id==id}?.let{save(c,it.copy(status=status,uri=uri?:it.uri))}}
 fun setFolder(c:Context,uri:String){p(c).edit().putString(F,uri).apply()}
 fun getFolder(c:Context):String?=p(c).getString(F,null)
 fun start(c:Context,url:String,title:String){val i=DownloadItem(url=url,title=title);save(c,i);val req=OneTimeWorkRequestBuilder<DownloadWorker>().setInputData(workDataOf("id" to i.id,"url" to url,"title" to title,"folder" to (getFolder(c)?:""))).build();WorkManager.getInstance(c).enqueue(req)}
}
