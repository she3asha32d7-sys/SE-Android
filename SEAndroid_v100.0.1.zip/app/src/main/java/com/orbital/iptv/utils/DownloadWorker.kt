package com.orbital.iptv.utils

import android.content.Context
import android.provider.DocumentsContract
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File

class DownloadWorker(ctx:Context,p:WorkerParameters):CoroutineWorker(ctx,p){
 override suspend fun doWork():Result{
  val id=inputData.getString("id")?:return Result.failure(); val url=inputData.getString("url")?:return Result.failure(); val title=inputData.getString("title")?:"video"; val folder=inputData.getString("folder").orEmpty(); DownloadStore.set(applicationContext,id,"DOWNLOADING")
  return try {
   val ext=if(url.substringBefore('?').lowercase().endsWith(".mkv"))".mkv" else if(url.substringBefore('?').lowercase().endsWith(".ts"))".ts" else ".mp4"
   val name=title.replace(Regex("[^A-Za-z0-9._ -]"),"_").take(100)+if(title.lowercase().endsWith(ext))"" else ext
   val out:java.io.OutputStream; var outUri:String?=null
   if(folder.isNotBlank()) {
    val tree=android.net.Uri.parse(folder); val docUri=DocumentsContract.buildDocumentUriUsingTree(tree,DocumentsContract.getTreeDocumentId(tree)); val uri=DocumentsContract.createDocument(applicationContext.contentResolver,docUri,"video/*",name) ?: throw IllegalStateException("Could not create file")
    out=applicationContext.contentResolver.openOutputStream(uri) ?: throw IllegalStateException("Could not open destination"); outUri=uri.toString()
   } else {
    val dir=File(applicationContext.getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS),"SE IPTV PLAYER").apply{mkdirs()}; val file=File(dir,name); out=file.outputStream(); outUri=android.net.Uri.fromFile(file).toString()
   }
   OkHttpClient().newCall(Request.Builder().url(url).build()).execute().use{r->{if(!r.isSuccessful)throw IllegalStateException("HTTP ${r.code}"); r.body!!.byteStream().use{input->out.use{input.copyTo(it)}}}}
   DownloadStore.set(applicationContext,id,"COMPLETED",outUri); Result.success()
  } catch(e:Exception){DownloadStore.set(applicationContext,id,"FAILED"); Result.failure()}
 }
}
