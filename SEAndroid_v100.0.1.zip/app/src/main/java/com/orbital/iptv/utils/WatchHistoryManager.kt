package com.orbital.iptv.utils

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

data class WatchHistoryItem(val id:String,val type:String,val title:String,val artUrl:String="",val streamUrl:String="",val streamId:Int=-1,val positionMs:Long=0L,val durationMs:Long=0L,val updatedAt:Long=System.currentTimeMillis())
object WatchHistoryManager {
    private const val PREFS="se_watch_history"; private const val KEY="items"; private const val MAX=15; private val gson=Gson()
    private fun prefs(c:Context)=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE)
    fun get(c:Context,type:String):List<WatchHistoryItem>{ val s=prefs(c).getString(KEY,null)?:return emptyList(); return try{gson.fromJson(s,object:TypeToken<List<WatchHistoryItem>>(){}.type)?:emptyList()}catch(_:Exception){emptyList()} .filter{it.type==type}.sortedByDescending{it.updatedAt}.take(MAX)}
    fun record(c:Context,item:WatchHistoryItem){val all=try{val s=prefs(c).getString(KEY,null); if(s==null) emptyList() else gson.fromJson<List<WatchHistoryItem>>(s,object:TypeToken<List<WatchHistoryItem>>(){}.type)?:emptyList()}catch(_:Exception){emptyList()}; val list=all.filterNot{it.id==item.id}.toMutableList(); list.add(0,item.copy(updatedAt=System.currentTimeMillis())); prefs(c).edit().putString(KEY,gson.toJson(list.take(100))).apply()}
    fun update(c:Context,id:String,pos:Long,dur:Long){val all=load(c).toMutableList(); val i=all.indexOfFirst{it.id==id}; if(i>=0){all[i]=all[i].copy(positionMs=pos,durationMs=dur,updatedAt=System.currentTimeMillis()); prefs(c).edit().putString(KEY,gson.toJson(all)).apply()}}
    fun remove(c:Context,id:String){val list=load(c).filterNot{it.id==id}; prefs(c).edit().putString(KEY,gson.toJson(list)).apply()}
    fun clear(c:Context){prefs(c).edit().clear().apply()}
    private fun load(c:Context)=try{val s=prefs(c).getString(KEY,null); if(s==null) emptyList() else gson.fromJson<List<WatchHistoryItem>>(s,object:TypeToken<List<WatchHistoryItem>>(){}.type)?:emptyList()}catch(_:Exception){emptyList()}
}
